/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static unsigned int ng0[] = {16768U, 0U};
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {4, 0};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {2U, 0U};
static unsigned int ng5[] = {3U, 0U};
static int ng6[] = {14, 0};



static void Cont_17_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t21[8];
    char t22[8];
    char t41[8];
    char t42[8];
    char t44[8];
    char t73[8];
    char t78[8];
    char t79[8];
    char t82[8];
    char t109[8];
    char t113[8];
    char t126[8];
    char t127[8];
    char t130[8];
    char t163[8];
    char t164[8];
    char t166[8];
    char t182[8];
    char t196[8];
    char t203[8];
    char t248[8];
    char t249[8];
    char t251[8];
    char t261[8];
    char t265[8];
    char t273[8];
    char t280[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t43;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    char *t80;
    char *t81;
    char *t83;
    char *t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    char *t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t110;
    char *t111;
    char *t112;
    char *t114;
    char *t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    char *t128;
    char *t129;
    char *t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    char *t145;
    char *t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    char *t152;
    char *t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    char *t165;
    char *t167;
    char *t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    char *t181;
    char *t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    char *t189;
    char *t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    char *t194;
    char *t195;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    char *t202;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    char *t207;
    char *t208;
    char *t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    int t227;
    int t228;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    char *t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    char *t241;
    char *t242;
    unsigned int t243;
    unsigned int t244;
    unsigned int t245;
    char *t246;
    char *t247;
    char *t250;
    char *t252;
    char *t253;
    char *t254;
    unsigned int t255;
    unsigned int t256;
    unsigned int t257;
    unsigned int t258;
    unsigned int t259;
    unsigned int t260;
    char *t262;
    char *t263;
    char *t264;
    char *t266;
    unsigned int t267;
    unsigned int t268;
    unsigned int t269;
    unsigned int t270;
    unsigned int t271;
    unsigned int t272;
    unsigned int t274;
    unsigned int t275;
    unsigned int t276;
    unsigned int t277;
    char *t278;
    char *t279;
    char *t281;
    char *t282;
    char *t283;
    char *t284;
    char *t285;
    char *t286;

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1048U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t17 = *((unsigned int *)t4);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t21, 8);

LAB16:    t281 = (t0 + 4472);
    t282 = (t281 + 56U);
    t283 = *((char **)t282);
    t284 = (t283 + 56U);
    t285 = *((char **)t284);
    memcpy(t285, t3, 8);
    xsi_driver_vfirst_trans(t281, 0, 31);
    t286 = (t0 + 4376);
    *((int *)t286) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = ((char*)((ng0)));
    goto LAB9;

LAB10:    t23 = (t0 + 1208U);
    t24 = *((char **)t23);
    memset(t22, 0, 8);
    t23 = (t24 + 4);
    t25 = *((unsigned int *)t23);
    t26 = (~(t25));
    t27 = *((unsigned int *)t24);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t23) != 0)
        goto LAB19;

LAB20:    t31 = (t22 + 4);
    t32 = *((unsigned int *)t22);
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB21;

LAB22:    t37 = *((unsigned int *)t22);
    t38 = (~(t37));
    t39 = *((unsigned int *)t31);
    t40 = (t38 || t39);
    if (t40 > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t31) > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t22) > 0)
        goto LAB27;

LAB28:    memcpy(t21, t41, 8);

LAB29:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t16, 32, t21, 32);
    goto LAB16;

LAB14:    memcpy(t3, t16, 8);
    goto LAB16;

LAB17:    *((unsigned int *)t22) = 1;
    goto LAB20;

LAB19:    t30 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB20;

LAB21:    t35 = (t0 + 1368U);
    t36 = *((char **)t35);
    goto LAB22;

LAB23:    t35 = (t0 + 2168U);
    t43 = *((char **)t35);
    t35 = ((char*)((ng1)));
    memset(t44, 0, 8);
    t45 = (t43 + 4);
    t46 = (t35 + 4);
    t47 = *((unsigned int *)t43);
    t48 = *((unsigned int *)t35);
    t49 = (t47 ^ t48);
    t50 = *((unsigned int *)t45);
    t51 = *((unsigned int *)t46);
    t52 = (t50 ^ t51);
    t53 = (t49 | t52);
    t54 = *((unsigned int *)t45);
    t55 = *((unsigned int *)t46);
    t56 = (t54 | t55);
    t57 = (~(t56));
    t58 = (t53 & t57);
    if (t58 != 0)
        goto LAB33;

LAB30:    if (t56 != 0)
        goto LAB32;

LAB31:    *((unsigned int *)t44) = 1;

LAB33:    memset(t42, 0, 8);
    t60 = (t44 + 4);
    t61 = *((unsigned int *)t60);
    t62 = (~(t61));
    t63 = *((unsigned int *)t44);
    t64 = (t63 & t62);
    t65 = (t64 & 1U);
    if (t65 != 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t60) != 0)
        goto LAB36;

LAB37:    t67 = (t42 + 4);
    t68 = *((unsigned int *)t42);
    t69 = *((unsigned int *)t67);
    t70 = (t68 || t69);
    if (t70 > 0)
        goto LAB38;

LAB39:    t74 = *((unsigned int *)t42);
    t75 = (~(t74));
    t76 = *((unsigned int *)t67);
    t77 = (t75 || t76);
    if (t77 > 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t67) > 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t42) > 0)
        goto LAB44;

LAB45:    memcpy(t41, t78, 8);

LAB46:    goto LAB24;

LAB25:    xsi_vlog_unsigned_bit_combine(t21, 32, t36, 32, t41, 32);
    goto LAB29;

LAB27:    memcpy(t21, t36, 8);
    goto LAB29;

LAB32:    t59 = (t44 + 4);
    *((unsigned int *)t44) = 1;
    *((unsigned int *)t59) = 1;
    goto LAB33;

LAB34:    *((unsigned int *)t42) = 1;
    goto LAB37;

LAB36:    t66 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t66) = 1;
    goto LAB37;

LAB38:    t71 = (t0 + 1688U);
    t72 = *((char **)t71);
    t71 = ((char*)((ng2)));
    memset(t73, 0, 8);
    xsi_vlog_unsigned_add(t73, 32, t72, 32, t71, 32);
    goto LAB39;

LAB40:    t80 = (t0 + 2168U);
    t81 = *((char **)t80);
    t80 = ((char*)((ng3)));
    memset(t82, 0, 8);
    t83 = (t81 + 4);
    t84 = (t80 + 4);
    t85 = *((unsigned int *)t81);
    t86 = *((unsigned int *)t80);
    t87 = (t85 ^ t86);
    t88 = *((unsigned int *)t83);
    t89 = *((unsigned int *)t84);
    t90 = (t88 ^ t89);
    t91 = (t87 | t90);
    t92 = *((unsigned int *)t83);
    t93 = *((unsigned int *)t84);
    t94 = (t92 | t93);
    t95 = (~(t94));
    t96 = (t91 & t95);
    if (t96 != 0)
        goto LAB50;

LAB47:    if (t94 != 0)
        goto LAB49;

LAB48:    *((unsigned int *)t82) = 1;

LAB50:    memset(t79, 0, 8);
    t98 = (t82 + 4);
    t99 = *((unsigned int *)t98);
    t100 = (~(t99));
    t101 = *((unsigned int *)t82);
    t102 = (t101 & t100);
    t103 = (t102 & 1U);
    if (t103 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t98) != 0)
        goto LAB53;

LAB54:    t105 = (t79 + 4);
    t106 = *((unsigned int *)t79);
    t107 = *((unsigned int *)t105);
    t108 = (t106 || t107);
    if (t108 > 0)
        goto LAB55;

LAB56:    t122 = *((unsigned int *)t79);
    t123 = (~(t122));
    t124 = *((unsigned int *)t105);
    t125 = (t123 || t124);
    if (t125 > 0)
        goto LAB57;

LAB58:    if (*((unsigned int *)t105) > 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t79) > 0)
        goto LAB61;

LAB62:    memcpy(t78, t126, 8);

LAB63:    goto LAB41;

LAB42:    xsi_vlog_unsigned_bit_combine(t41, 32, t73, 32, t78, 32);
    goto LAB46;

LAB44:    memcpy(t41, t73, 8);
    goto LAB46;

LAB49:    t97 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t97) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t79) = 1;
    goto LAB54;

LAB53:    t104 = (t79 + 4);
    *((unsigned int *)t79) = 1;
    *((unsigned int *)t104) = 1;
    goto LAB54;

LAB55:    t110 = ((char*)((ng1)));
    t111 = (t0 + 1848U);
    t112 = *((char **)t111);
    t111 = (t0 + 1528U);
    t114 = *((char **)t111);
    memset(t113, 0, 8);
    t111 = (t113 + 4);
    t115 = (t114 + 4);
    t116 = *((unsigned int *)t114);
    t117 = (t116 >> 28);
    *((unsigned int *)t113) = t117;
    t118 = *((unsigned int *)t115);
    t119 = (t118 >> 28);
    *((unsigned int *)t111) = t119;
    t120 = *((unsigned int *)t113);
    *((unsigned int *)t113) = (t120 & 15U);
    t121 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t121 & 15U);
    xsi_vlogtype_concat(t109, 32, 32, 3U, t113, 4, t112, 26, t110, 2);
    goto LAB56;

LAB57:    t128 = (t0 + 2168U);
    t129 = *((char **)t128);
    t128 = ((char*)((ng4)));
    memset(t130, 0, 8);
    t131 = (t129 + 4);
    t132 = (t128 + 4);
    t133 = *((unsigned int *)t129);
    t134 = *((unsigned int *)t128);
    t135 = (t133 ^ t134);
    t136 = *((unsigned int *)t131);
    t137 = *((unsigned int *)t132);
    t138 = (t136 ^ t137);
    t139 = (t135 | t138);
    t140 = *((unsigned int *)t131);
    t141 = *((unsigned int *)t132);
    t142 = (t140 | t141);
    t143 = (~(t142));
    t144 = (t139 & t143);
    if (t144 != 0)
        goto LAB67;

LAB64:    if (t142 != 0)
        goto LAB66;

LAB65:    *((unsigned int *)t130) = 1;

LAB67:    memset(t127, 0, 8);
    t146 = (t130 + 4);
    t147 = *((unsigned int *)t146);
    t148 = (~(t147));
    t149 = *((unsigned int *)t130);
    t150 = (t149 & t148);
    t151 = (t150 & 1U);
    if (t151 != 0)
        goto LAB68;

LAB69:    if (*((unsigned int *)t146) != 0)
        goto LAB70;

LAB71:    t153 = (t127 + 4);
    t154 = *((unsigned int *)t127);
    t155 = *((unsigned int *)t153);
    t156 = (t154 || t155);
    if (t156 > 0)
        goto LAB72;

LAB73:    t159 = *((unsigned int *)t127);
    t160 = (~(t159));
    t161 = *((unsigned int *)t153);
    t162 = (t160 || t161);
    if (t162 > 0)
        goto LAB74;

LAB75:    if (*((unsigned int *)t153) > 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t127) > 0)
        goto LAB78;

LAB79:    memcpy(t126, t163, 8);

LAB80:    goto LAB58;

LAB59:    xsi_vlog_unsigned_bit_combine(t78, 32, t109, 32, t126, 32);
    goto LAB63;

LAB61:    memcpy(t78, t109, 8);
    goto LAB63;

LAB66:    t145 = (t130 + 4);
    *((unsigned int *)t130) = 1;
    *((unsigned int *)t145) = 1;
    goto LAB67;

LAB68:    *((unsigned int *)t127) = 1;
    goto LAB71;

LAB70:    t152 = (t127 + 4);
    *((unsigned int *)t127) = 1;
    *((unsigned int *)t152) = 1;
    goto LAB71;

LAB72:    t157 = (t0 + 2008U);
    t158 = *((char **)t157);
    goto LAB73;

LAB74:    t157 = (t0 + 2168U);
    t165 = *((char **)t157);
    t157 = ((char*)((ng5)));
    memset(t166, 0, 8);
    t167 = (t165 + 4);
    t168 = (t157 + 4);
    t169 = *((unsigned int *)t165);
    t170 = *((unsigned int *)t157);
    t171 = (t169 ^ t170);
    t172 = *((unsigned int *)t167);
    t173 = *((unsigned int *)t168);
    t174 = (t172 ^ t173);
    t175 = (t171 | t174);
    t176 = *((unsigned int *)t167);
    t177 = *((unsigned int *)t168);
    t178 = (t176 | t177);
    t179 = (~(t178));
    t180 = (t175 & t179);
    if (t180 != 0)
        goto LAB84;

LAB81:    if (t178 != 0)
        goto LAB83;

LAB82:    *((unsigned int *)t166) = 1;

LAB84:    memset(t182, 0, 8);
    t183 = (t166 + 4);
    t184 = *((unsigned int *)t183);
    t185 = (~(t184));
    t186 = *((unsigned int *)t166);
    t187 = (t186 & t185);
    t188 = (t187 & 1U);
    if (t188 != 0)
        goto LAB85;

LAB86:    if (*((unsigned int *)t183) != 0)
        goto LAB87;

LAB88:    t190 = (t182 + 4);
    t191 = *((unsigned int *)t182);
    t192 = *((unsigned int *)t190);
    t193 = (t191 || t192);
    if (t193 > 0)
        goto LAB89;

LAB90:    memcpy(t203, t182, 8);

LAB91:    memset(t164, 0, 8);
    t235 = (t203 + 4);
    t236 = *((unsigned int *)t235);
    t237 = (~(t236));
    t238 = *((unsigned int *)t203);
    t239 = (t238 & t237);
    t240 = (t239 & 1U);
    if (t240 != 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t235) != 0)
        goto LAB101;

LAB102:    t242 = (t164 + 4);
    t243 = *((unsigned int *)t164);
    t244 = *((unsigned int *)t242);
    t245 = (t243 || t244);
    if (t245 > 0)
        goto LAB103;

LAB104:    t274 = *((unsigned int *)t164);
    t275 = (~(t274));
    t276 = *((unsigned int *)t242);
    t277 = (t275 || t276);
    if (t277 > 0)
        goto LAB105;

LAB106:    if (*((unsigned int *)t242) > 0)
        goto LAB107;

LAB108:    if (*((unsigned int *)t164) > 0)
        goto LAB109;

LAB110:    memcpy(t163, t280, 8);

LAB111:    goto LAB75;

LAB76:    xsi_vlog_unsigned_bit_combine(t126, 32, t158, 32, t163, 32);
    goto LAB80;

LAB78:    memcpy(t126, t158, 8);
    goto LAB80;

LAB83:    t181 = (t166 + 4);
    *((unsigned int *)t166) = 1;
    *((unsigned int *)t181) = 1;
    goto LAB84;

LAB85:    *((unsigned int *)t182) = 1;
    goto LAB88;

LAB87:    t189 = (t182 + 4);
    *((unsigned int *)t182) = 1;
    *((unsigned int *)t189) = 1;
    goto LAB88;

LAB89:    t194 = (t0 + 2328U);
    t195 = *((char **)t194);
    memset(t196, 0, 8);
    t194 = (t195 + 4);
    t197 = *((unsigned int *)t194);
    t198 = (~(t197));
    t199 = *((unsigned int *)t195);
    t200 = (t199 & t198);
    t201 = (t200 & 1U);
    if (t201 != 0)
        goto LAB92;

LAB93:    if (*((unsigned int *)t194) != 0)
        goto LAB94;

LAB95:    t204 = *((unsigned int *)t182);
    t205 = *((unsigned int *)t196);
    t206 = (t204 & t205);
    *((unsigned int *)t203) = t206;
    t207 = (t182 + 4);
    t208 = (t196 + 4);
    t209 = (t203 + 4);
    t210 = *((unsigned int *)t207);
    t211 = *((unsigned int *)t208);
    t212 = (t210 | t211);
    *((unsigned int *)t209) = t212;
    t213 = *((unsigned int *)t209);
    t214 = (t213 != 0);
    if (t214 == 1)
        goto LAB96;

LAB97:
LAB98:    goto LAB91;

LAB92:    *((unsigned int *)t196) = 1;
    goto LAB95;

LAB94:    t202 = (t196 + 4);
    *((unsigned int *)t196) = 1;
    *((unsigned int *)t202) = 1;
    goto LAB95;

LAB96:    t215 = *((unsigned int *)t203);
    t216 = *((unsigned int *)t209);
    *((unsigned int *)t203) = (t215 | t216);
    t217 = (t182 + 4);
    t218 = (t196 + 4);
    t219 = *((unsigned int *)t182);
    t220 = (~(t219));
    t221 = *((unsigned int *)t217);
    t222 = (~(t221));
    t223 = *((unsigned int *)t196);
    t224 = (~(t223));
    t225 = *((unsigned int *)t218);
    t226 = (~(t225));
    t227 = (t220 & t222);
    t228 = (t224 & t226);
    t229 = (~(t227));
    t230 = (~(t228));
    t231 = *((unsigned int *)t209);
    *((unsigned int *)t209) = (t231 & t229);
    t232 = *((unsigned int *)t209);
    *((unsigned int *)t209) = (t232 & t230);
    t233 = *((unsigned int *)t203);
    *((unsigned int *)t203) = (t233 & t229);
    t234 = *((unsigned int *)t203);
    *((unsigned int *)t203) = (t234 & t230);
    goto LAB98;

LAB99:    *((unsigned int *)t164) = 1;
    goto LAB102;

LAB101:    t241 = (t164 + 4);
    *((unsigned int *)t164) = 1;
    *((unsigned int *)t241) = 1;
    goto LAB102;

LAB103:    t246 = (t0 + 1528U);
    t247 = *((char **)t246);
    t246 = ((char*)((ng2)));
    memset(t248, 0, 8);
    xsi_vlog_unsigned_add(t248, 32, t247, 32, t246, 32);
    t250 = ((char*)((ng1)));
    t252 = (t0 + 1848U);
    t253 = *((char **)t252);
    memset(t251, 0, 8);
    t252 = (t251 + 4);
    t254 = (t253 + 4);
    t255 = *((unsigned int *)t253);
    t256 = (t255 >> 0);
    *((unsigned int *)t251) = t256;
    t257 = *((unsigned int *)t254);
    t258 = (t257 >> 0);
    *((unsigned int *)t252) = t258;
    t259 = *((unsigned int *)t251);
    *((unsigned int *)t251) = (t259 & 65535U);
    t260 = *((unsigned int *)t252);
    *((unsigned int *)t252) = (t260 & 65535U);
    t262 = ((char*)((ng6)));
    t263 = (t0 + 1848U);
    t264 = *((char **)t263);
    memset(t265, 0, 8);
    t263 = (t265 + 4);
    t266 = (t264 + 4);
    t267 = *((unsigned int *)t264);
    t268 = (t267 >> 15);
    t269 = (t268 & 1);
    *((unsigned int *)t265) = t269;
    t270 = *((unsigned int *)t266);
    t271 = (t270 >> 15);
    t272 = (t271 & 1);
    *((unsigned int *)t263) = t272;
    xsi_vlog_mul_concat(t261, 14, 1, t262, 1U, t265, 1);
    xsi_vlogtype_concat(t249, 32, 32, 3U, t261, 14, t251, 16, t250, 2);
    memset(t273, 0, 8);
    xsi_vlog_unsigned_add(t273, 32, t248, 32, t249, 32);
    goto LAB104;

LAB105:    t278 = (t0 + 1688U);
    t279 = *((char **)t278);
    t278 = ((char*)((ng2)));
    memset(t280, 0, 8);
    xsi_vlog_unsigned_add(t280, 32, t279, 32, t278, 32);
    goto LAB106;

LAB107:    xsi_vlog_unsigned_bit_combine(t163, 32, t273, 32, t280, 32);
    goto LAB111;

LAB109:    memcpy(t163, t273, 8);
    goto LAB111;

}

static void NetDecl_24_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 4056U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1528U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 28);
    *((unsigned int *)t3) = t7;
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 28);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t10 & 15U);
    t11 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t11 & 15U);
    t12 = (t0 + 4536);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t16, 0, 8);
    t17 = 15U;
    t18 = t17;
    t19 = (t3 + 4);
    t20 = *((unsigned int *)t3);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = (t16 + 4);
    t23 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t23 | t17);
    t24 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t24 | t18);
    xsi_driver_vfirst_trans(t12, 0, 3U);
    t25 = (t0 + 4392);
    *((int *)t25) = 1;

LAB1:    return;
}


extern void work_m_00000000002463608433_3650585529_init()
{
	static char *pe[] = {(void *)Cont_17_0,(void *)NetDecl_24_1};
	xsi_register_didat("work_m_00000000002463608433_3650585529", "isim/mips.exe.sim/work/m_00000000002463608433_3650585529.didat");
	xsi_register_executes(pe);
}
